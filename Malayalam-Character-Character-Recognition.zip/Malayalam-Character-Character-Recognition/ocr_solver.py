from collections import defaultdict
import math
import sys

# Set to store all the possible characters
TRAIN_LETTERS = set("അആഇഈഉഊഋഎഏഐഒഓഔകഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരലവശഷസഹളഴറ0123456789(),.-!?\"' ")
CHARACTER_WIDTH = 14
CHARACTER_HEIGHT = 25
max_val = 10000000.0  # Maximum value
min_val = sys.float_info.epsilon  # Smallest possible value


class OCRSolver:
    """Class that contains all the logic to perform Optical Character Recognition (OCR) for test image 
    """

    def __init__(self, train_letters, test_letters, train_txt_fname):
        """
        :param train_letters:   Dictionary that maps from a character to the correct representation of the character
        :param test_letters:    List of test character representations for which we need to find the correct character
        :param train_txt_fname: Name of the text file that will be used to compute non-emission probabilities
        """
        self.train_letters = train_letters
        self.test_letters = test_letters
        self.init_prob = dict()
        self.char_prob = {char: min_val for char in TRAIN_LETTERS}
        self.trans_prob = defaultdict(lambda: defaultdict(lambda: min_val))
        self.emit_prob = defaultdict(dict)

        self.train(train_txt_fname)

    def print_inputs(self):
        def print_dict(dict_to_print, items_to_print):
            """Static method to print the dictionary
            :param dict_to_print:  Dictionary that needs to be printed
            :param items_to_print: Number of items that need to be printed
            """
            for key, val in dict_to_print.items():
                items_to_print -= 1
                if items_to_print == 0:
                    break
                print('Key ->', key, '   Val ->', val)

        print('Printing initial probabilities', len(self.init_prob))
        print('Size of initial probabilities', sys.getsizeof(self.init_prob))
        print_dict(self.init_prob, sys.maxsize)

        print('Printing tag probabilities', len(self.char_prob))
        print('Size of tag probabilities', sys.getsizeof(self.init_prob))
        print_dict(self.char_prob, sys.maxsize)

        print('Printing transition probabilities', len(self.trans_prob))
        print('Size of transition probabilities', sys.getsizeof(self.trans_prob))
        print_dict(self.trans_prob, sys.maxsize)

        print('Printing emission probabilities', len(self.emit_prob))
        print('Size of emission probabilities', sys.getsizeof(self.emit_prob))
        print_dict(self.emit_prob, 50)

    @staticmethod
    def normalize_dict(dict_to_normalize):
        """Transforms count of a dictionaries to natural log of the probabilities
        :param dict_to_normalize: Dictionary that needs to be normalized
        """
        total_log = math.log(sum(dict_to_normalize.values()))
        for key, val in dict_to_normalize.items():
            dict_to_normalize[key] = max_val if val < 1 else total_log - math.log(val)

    def compute_emission(self):
        """Populates the emission probabilities table (self.emit_prob) by comparing the test letters with training
           characters (self.train_letters) and using a Naive Bayes classifier to compute the matching probability
        """
        def match_grids(grid1, grid2):
            matches = sum(ch1 == ch2 for row1, row2 in zip(grid1, grid2) for ch1, ch2 in zip(row1, row2))
            return matches

        total_pixels = CHARACTER_WIDTH * CHARACTER_HEIGHT

        for curr_index, test_letter in enumerate(self.test_letters):
            for train_letter, train_letter_grid in self.train_letters.items():
                matched = match_grids(test_letter, train_letter_grid)
                unmatched = total_pixels - matched
                match_prob = (matched + 0.0) / total_pixels

                prob = (match_prob ** matched) * ((1 - match_prob) ** unmatched)
                self.emit_prob[curr_index][train_letter] = max_val if prob == 0 else -math.log(prob)

    def train(self, train_txt_fname):
        """Calculates the three probability tables for the given data
        :param train_txt_fname: Filename of the file containing the text corpus
        """
        def clean_string(str_to_clean):
            return ''.join([ch if ch in TRAIN_LETTERS else ' ' for ch in str_to_clean])

        with open(train_txt_fname, 'r', encoding='utf-8') as train_txt_file:
            train_text = clean_string(train_txt_file.read())
            is_initial_letter = True

            for index in range(0, len(train_text) - 1):
                curr_char, next_char = train_text[index], train_text[index + 1]

                if is_initial_letter:
                    self.init_prob[curr_char] = self.init_prob.get(curr_char, 0) + 1
                    is_initial_letter = False

                if curr_char == '.':
                    is_initial_letter = True

                self.trans_prob[curr_char][next_char] += 1
                self.char_prob[curr_char] += 1

        self.normalize_dict(self.init_prob)
        self.normalize_dict(self.char_prob)
        for row_dict in self.trans_prob.values():
            self.normalize_dict(row_dict)

        self.compute_emission()

    def get_emission_probs(self, noisy_char):
        return {char: self.emit_prob[noisy_char].get(char, max_val) for char in TRAIN_LETTERS}

    def simplified(self):
        output_chars = []
        for index in range(len(self.test_letters)):
            best_ch, best_prob = min(self.emit_prob[index].items(), key=lambda x: x[1] + self.char_prob[x[0]])
            output_chars.append(best_ch)
        print('Simple:', ''.join(output_chars))

    def hmm_ve(self):
        chars = dict()  # Dictionary to store all probabilities
        char_dict = dict()
    
        epsilon = sys.float_info.epsilon  # A very small value to prevent math domain errors
    
        for char in TRAIN_LETTERS:  # Calculating for the first character
            if char not in self.emit_prob[0].keys() or char not in self.init_prob.keys():
                char_dict[char] = sys.float_info.max
            else:
                char_dict[char] = self.char_prob[char] + self.emit_prob[0][char]
        chars[0] = char_dict

        for w in range(1, len(self.test_letters)):  # Calculating for the remaining characters
            char_dict = dict()
            prev_chars_dict = chars[w - 1]
        
            for char in TRAIN_LETTERS:
                prob = epsilon  # Avoid zero probabilities
                for prev_char in prev_chars_dict:  # Scanning probabilities of the previous character
                    current_prob = prev_chars_dict[prev_char] + self.trans_prob[prev_char][char]
                    prob += math.exp(-current_prob)  # For adding all the probabilities
            
                if char not in self.emit_prob[w].keys():
                    char_dict[char] = sys.float_info.max  # Assign maximum value for a new character
                else:
                    # Add epsilon to the sum to prevent log(0)
                    char_dict[char] = -math.log(prob + epsilon) + self.emit_prob[w][char]
            chars[w] = char_dict

        print('HMM VE:', ''.join(
            [min(chars[w], key=chars[w].get) for w in range(len(self.test_letters))])  # Printing the characters that have maximum probability
        )


    def hmm_viterbi(self):
        char_list = list(TRAIN_LETTERS)
        rows, cols = len(char_list), len(self.test_letters)
        vit_matrix = [[None] * cols for _ in range(rows)]

        for col_index in range(cols):
            curr_emission_probs = self.get_emission_probs(col_index)
            for row_index, curr_char in enumerate(char_list):
                if col_index == 0:
                    vit_matrix[row_index][col_index] = (-1, curr_emission_probs[curr_char] + self.init_prob.get(curr_char, max_val))
                else:
                    best_prob_tuple = min(
                        ((prev_row_index, vit_matrix[prev_row_index][col_index-1][1] + self.trans_prob[char_list[prev_row_index]][curr_char] + curr_emission_probs[curr_char]) for prev_row_index in range(rows)),
                        key=lambda x: x[1])
                    vit_matrix[row_index][col_index] = best_prob_tuple

        max_index, _ = min(enumerate([vit_matrix[row][cols-1][1] for row in range(rows)]), key=lambda x: x[1])
        output_list = []
        for col in range(cols-1, 0, -1):
            output_list.insert(0, char_list[max_index])
            max_index = vit_matrix[max_index][col][0]
        output_list.insert(0, char_list[max_index])
        print('HMM MAP:', ''.join(output_list))
