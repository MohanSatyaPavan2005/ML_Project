from collections import defaultdict
import math
import sys

# Set to store all the possible characters
TRAIN_LETTERS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789(),.-!?\"' ")
CHARACTER_WIDTH = 14
CHARACTER_HEIGHT = 25
max_val = 10000000.0  # Maximum value
min_val = sys.float_info.epsilon  # Smallest possible value


class OCRSolver:
    """Class that contains all the logic to perform Optical Character Recognition (OCR) for test image 
    """

    def __init__(self, train_letters, test_letters, train_txt_fname):
        """
        :param train_letters:   Dictionary that maps from a character to the correct representation of the character
        :param test_letters:    List of test character representations for which we need to find the correct character
        :param train_txt_fname: Name of the text file that will be used to compute non-emission probabilities
        """
        
        self.train_letters = train_letters

        self.test_letters = test_letters

        self.init_prob = dict()

        
        self.char_prob = dict()
        for char in TRAIN_LETTERS:
            self.char_prob[char] = min_val

       
        self.trans_prob = defaultdict(dict)
        for row_char in TRAIN_LETTERS:
            for col_char in TRAIN_LETTERS:
                self.trans_prob[row_char][col_char] = min_val

        
        self.emit_prob = defaultdict(dict)

        self.train(train_txt_fname)

    def print_inputs(self):
        def print_dict(dict_to_print, items_to_print):
            """Static method to print the dictionary
            :param dict_to_print:  Dictionary that needs to be printed
            :param items_to_print: Number of items that need to be printed
            """
            for key, val in dict_to_print.items():
                items_to_print -= 1
                if items_to_print == 0:
                    break
                print('Key ->', key, '   Val ->', val)


        # print_inputs() starts from here
        print('Printing initial probabilities', len(self.init_prob))
        print('Size of initial probabilities', sys.getsizeof(self.init_prob))
        print_dict(self.init_prob, sys.maxsize)

        print('Printing tag probabilities', len(self.char_prob))
        print('Size of tag probabilities', sys.getsizeof(self.init_prob))
        print_dict(self.char_prob, sys.maxsize)

        print('Printing transition probabilities', len(self.trans_prob))
        print('Size of transition probabilities', sys.getsizeof(self.trans_prob))
        print_dict(self.trans_prob, sys.maxsize)

        print('Printing emission probabilities', len(self.emit_prob))
        print('Size of emission probabilities', sys.getsizeof(self.emit_prob))
        print_dict(self.emit_prob, 50)
        # sys.exit(0)

    @staticmethod
    def normalize_dict(dict_to_normalize):
        """Transforms count of a dictionaries to natural log of the probabilties
        :param dict_to_normalize: Dictionary that needs to be normalized
        :return:
        """
        total_log = math.log(sum(dict_to_normalize.values()))
        for key, val in dict_to_normalize.items():
            dict_to_normalize[key] = max_val if val < 1 else total_log - math.log(val)

    def compute_emission(self):
        """Populates the emission probabilities table (self.emit_prob) by comparing the test letters with training
           characters (self.train_letters) and using a Naive Bayes classifier to compute the matching probability
        """

        def match_grids(grid1, grid2):
            """Performs the cell-wise character matching of 2 grids (list of strings) and returns the number of matches
               Example: For input strings: ['*','_','*'] and ['*','*','*'],
               this method will return 8
               Constraint: The size of the 2 grids should be equal
            :param grid1: First grid (list of strings)
            :param grid2: Second grid (list of strings)
            :return: The number of cell-wise character matches
            """
            matches = 0
            for row1, row2 in zip(grid1, grid2):
                for ch1, ch2 in zip(row1, row2):
                    if ch1 == ch2:
                        matches += 1
            return matches

        # compute_emission() starts from here
        total_pixels = CHARACTER_WIDTH * CHARACTER_HEIGHT

        for curr_index, test_letter in enumerate(self.test_letters):
            for train_letter, train_letter_grid in self.train_letters.items():
                # Compute the probability of a noisy character representing a char from the
                matched = match_grids(test_letter, train_letter_grid)
                unmmatched = total_pixels - matched
                match_prob = (matched + 0.0) / total_pixels

                # Computing the probability of the test character being the train character
                prob = (match_prob ** matched) * ((1 - match_prob) ** unmmatched)
                # self.emit_prob[curr_index][train_letter] = total_pixels_log - math.log(matched + 0.00001) - \

                self.emit_prob[curr_index][train_letter] = max_val if prob == 0 else -math.log(prob)
                # print(self.emit_prob)

    def train(self, train_txt_fname):
        """Calculates the three probability tables for the given data
        :param train_txt_fname: Filename of the file containing the text corpus
        """

        def clean_string(str_to_clean):
            """Cleans the given string by removing special characters
            :param str_to_clean: The string that needs to be cleaned
            :return: The clean string
            """
            str_to_clean = list(str_to_clean)
            idx = 0
            while idx < len(str_to_clean) - 1:
                curr_ch = str_to_clean[idx]
                next_ch = str_to_clean[idx + 1]
                if curr_ch not in TRAIN_LETTERS:
                    str_to_clean[idx] = ' '
                if next_ch not in TRAIN_LETTERS:
                    str_to_clean[idx + 1] = ' '
                if next_ch == ' ' and (curr_ch == '.' or curr_ch == ' '):
                    del str_to_clean[idx + 1]
                else:
                    idx += 1
            return str_to_clean

        # train() starts from here
        with open(train_txt_fname, 'r') as train_txt_file:
            train_text = clean_string(train_txt_file.read())
            is_initial_letter = True
            for index in range(0, len(train_text) - 1):
                curr_char = train_text[index]
                next_char = train_text[index + 1]

                if is_initial_letter:
                    if curr_char not in self.init_prob:
                        self.init_prob[curr_char] = 0
                    self.init_prob[curr_char] += 1
                    is_initial_letter = False

                if curr_char == '.':
                    is_initial_letter = True

                self.trans_prob[curr_char][next_char] += 1
                self.char_prob[curr_char] += 1

        
        self.normalize_dict(self.init_prob)

        
        self.normalize_dict(self.char_prob)

       
        for row_dict in self.trans_prob.values():
            
            self.normalize_dict(row_dict)

        self.compute_emission()
        

    def get_emission_probs(self, noisy_char):
        """Computes emission probabilities for a word
        :param noisy_char: string word
        :return: A dictionary mapping tag to the emission probability {'noun': 1.234, 'verb': 2.345) ...)
        """
        emission_prob_dict = dict()
        for char in TRAIN_LETTERS:
            if noisy_char in self.emit_prob and char in self.emit_prob[noisy_char]:
                emission_prob_dict[char] = self.emit_prob[noisy_char][char]
            else:
                emission_prob_dict[char] = max_val
        return emission_prob_dict

    def simplified(self):
        """Returns the best matching character for every test characters
        :return: set of characters (string) that best match the test characters
        """
        output_chars = list()
        for index, test_letter_grid in enumerate(self.test_letters):
            

            (best_ch, best_prob) = (None, sys.float_info.max)
            for ch, prob in self.emit_prob[index].items():
                curr_prob = prob + self.char_prob[ch]
                if curr_prob < best_prob:
                    (best_ch, best_prob) = (ch, curr_prob)
            output_chars.append(best_ch)
            
        print('Simple:', ''.join(output_chars))


    def hmm_ve(self):
        """Performs OCR by performing variable elimination on Hidden Markov model constructed by keeping
            the test characters on observed states, and computing the best likely values of hidden states
        :return: set of characters (string) that best match the test characters
        """
        chars = dict()  # Dictionary to store all probabilities
        char_dict = dict()
        for char in TRAIN_LETTERS:  # Calculating for the first character
            if char not in self.emit_prob[0].keys() or char not in self.init_prob.keys():
                char_dict[char] = sys.float_info.max
            else:
                char_dict[char] = self.char_prob[char] + self.emit_prob[0][char]
        chars[0] = char_dict

        for w in range(1, len(self.test_letters)):  # Calculating for the remaining characters
            char_dict = dict()
            prev_chars_dict = chars[w - 1]
            for char in TRAIN_LETTERS:
                prob = (1 / sys.float_info.max)
                for prev_char in prev_chars_dict:  # Scanning probabilities of the previous character
                    current_prob = prev_chars_dict[prev_char] + self.trans_prob[prev_char][char]
                    prob += math.exp(-current_prob)  # For adding all the probabilities
                if char not in self.emit_prob[w].keys():
                    char_dict[char] = sys.float_info.max  # Assign maximum value for a new character
                else:
                    char_dict[char] = -math.log(prob) + self.emit_prob[w][char]
            chars[w] = char_dict
        print('HMM VE:', ''.join([list(chars[w].keys())[list(chars[w].values()).index(min(chars[w].values()))] for w in range(len(self.test_letters))]))
 # Printing the characters that have maximum probability

    def hmm_viterbi(self):
        """Performs OCR by solving Viterbi algorithm on Hidden Markov model constructed by keeping
           the test characters on observed states, and computing the best likely values of hidden states
        :return: set of characters (string) that best match the test characters
        """
        char_list = list(TRAIN_LETTERS)  # Converting tag_set to a list to have indexes to refer
        rows = len(char_list)
        cols = len(self.test_letters)
        vit_matrix = [[None] * cols for i in range(rows)]

        
        for col_index in range(len(self.test_letters)):
            curr_emission_probs = self.get_emission_probs(col_index)

            for row_index, curr_char in enumerate(char_list):
                
                if col_index == 0:
                    init_prob = self.init_prob[curr_char] if curr_char in self.init_prob else max_val
                    vit_matrix[row_index][col_index] = (-1, curr_emission_probs[curr_char] + init_prob)
                
                else:
                    best_prob_tuple = (-1, 200000000.0)
                    for prev_row_index, prev_char in enumerate(char_list):
                        prev_prob = vit_matrix[prev_row_index][col_index - 1][1]
                        curr_prob = prev_prob + self.trans_prob[prev_char][curr_char] + curr_emission_probs[curr_char]
                        if curr_prob < best_prob_tuple[1]:
                            best_prob_tuple = (prev_row_index, curr_prob)
                    vit_matrix[row_index][col_index] = (best_prob_tuple[0], best_prob_tuple[1])

        
        (max_index, max_prob) = (-1, max_val)
        for row in range(rows):
            curr_prob = vit_matrix[row][cols - 1][1]
            if curr_prob < max_prob:
                (max_index, max_prob) = (row, curr_prob)

        output_list = list()  # List to store the output tags
        
        for col in range(cols - 1, 0, -1):
            output_list.insert(0, char_list[max_index])
            max_index = vit_matrix[max_index][col][0]
        output_list.insert(0, char_list[max_index])
        print('HMM MAP:', ''.join(output_list))
