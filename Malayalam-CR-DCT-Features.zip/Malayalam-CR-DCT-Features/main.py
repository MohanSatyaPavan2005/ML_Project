from functions import load_data, train_hmm, recognize_sequence, evaluate_performance

# Load the data
X, y = load_data()

# Prepare lengths of sequences (assuming each row corresponds to one sequence)
lengths = [len(X) for _ in y]  # Modify this if sequences have variable lengths

# Train the HMM model
hmm_model = train_hmm(X, lengths)

# Recognize character sequences
predicted_sequence = recognize_sequence(hmm_model, X)

# Evaluate the performance by comparing predicted sequences with ground truth
accuracy = evaluate_performance(predicted_sequence, y)

# Output the recognition accuracy
print(f"Recognition Accuracy: {accuracy * 100:.2f}%")
