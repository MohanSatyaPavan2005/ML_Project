import pandas as pd
from hmmlearn import hmm

# Function to load the data from the excel and CSV files
def load_data():
    # Load ground truth and DCT features from the files
    line_gt = pd.read_excel('C:/Users/pavan/Desktop/ML-B20/Project-Material/ML_Code/Malayalam-CR-DCT-Features/line_gt 2.xlsx')
    sfr_dct_line = pd.read_csv('C:/Users/pavan/Desktop/ML-B20/Project-Material/ML_Code/Malayalam-CR-DCT-Features/SFR_DCT_LINE.csv')
    
    # Convert the features and labels to numpy arrays
    X = sfr_dct_line.values  # DCT features
    y = line_gt['Character_String'].values  # Ground truth character sequences
    
    return X, y

# Function to train the HMM using Baum-Welch algorithm
def train_hmm(X, lengths, n_components=11):
    # Initialize the HMM with specified number of states and diagonal covariance
    hmm_model = hmm.GaussianHMM(n_components=n_components, covariance_type="diag", n_iter=100)
    
    # Fit the HMM model on the feature data
    hmm_model.fit(X, lengths)
    
    return hmm_model

# Function to recognize sequences using the Viterbi algorithm
def recognize_sequence(hmm_model, X):
    # Decode the most likely sequence using Viterbi algorithm
    logprob, predicted_sequence = hmm_model.decode(X, algorithm="viterbi")
    
    return predicted_sequence

# Function to evaluate the accuracy of the recognition
def evaluate_performance(predicted_sequence, true_sequence):
    from sklearn.metrics import accuracy_score
    
    # Calculate the accuracy
    accuracy = accuracy_score(true_sequence, predicted_sequence)
    
    return accuracy
